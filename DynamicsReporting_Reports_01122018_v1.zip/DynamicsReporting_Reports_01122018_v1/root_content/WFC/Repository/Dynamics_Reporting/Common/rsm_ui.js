/*
 ===========================================================================================


    Date:    07/22/2016        Created By: Shravan Panuganti
    I copied Jeff Rustandi's rdf-ui and made this file to create a different version of it.
============================================================================================


 */
$.fn.rdftbuttons = function( options ) {
    var ctrl = this;
    var className = $(this).attr("class");
    var classButton = (typeof className === 'undefined')? 'rdf-tbutton' : className+'-rdf-tbutton';




    $(this).find('td').each(function() {
        if ( $(this).find('input').first().is(':checked') ) {
            $(this).toggleClass('active');
        }
    });




    $(this).click(function() {
        setTimeout(function() {
            $(ctrl).find('td').each(function() {
                if ( $(this).find('input').first().is(':checked') )
                    $(this).attr('class', 'active');
                else
                    $(this).attr('class', '');
            });
        },100);
    });




    $(this).attr('class', classButton);
    $(this).find('label').each(function() { $(this).css('cursor', 'pointer'); });
    $(this).find('span').each(function() { $(this).css('cursor', 'pointer'); });
    $(this).find('td').each(function(){
        $(this).click(function(e) {
            e.preventDefault();
            $(this).find('input').first().click();
        });
    });




    return this;
}




$.fn.rdftrbuttons = function( options ) {
    var ctrl = this;
    var className = $(this).attr("class");
    var classButton = (typeof className === 'undefined')? 'rdf-tbutton' : className+'-rdf-tbutton';




    $(this).find('td').each(function() {
        if ( $(this).find('input').first().is(':checked') ) {
            $(this).toggleClass('active');
        }
    });




    $(this).attr('class', classButton);
    $(this).find('label').each(function() { $(this).css('cursor', 'pointer'); });
    $(this).find('span').each(function() { $(this).css('cursor', 'pointer'); });
    $(this).find('td').each(function(){
        $(this).click(function(e) {
            //e.preventDefault();
            var currentId = $(this).find('input').first().attr('id');
            $(this).parent().find('input').each(function(){
                if ( $(this).attr('id') != currentId )
                    this.checked = false;
                else
                    this.checked = true;
            });
            setTimeout(function(){ resetButtonSet(ctrl); },150);
        });
    });




    return this;
}




$.fn.rdfvtbuttons = function( options ) {
    var ctrl = this;
    var className = $(this).attr("class");
    var classButton = (typeof className === 'undefined')? 'rdf-vtbutton' : className+'-rdf-vtbutton';




    $(this).find('td').each(function() {
        if ( $(this).find('input').first().is(':checked') ) {
            $(this).toggleClass('active');
        }
    });




    /* Hide extra td created by WF 8.0.09 */
    $(this).find('td:nth-child(2)').each(function(){
        if ($(this).html().trim() == '')
            $(this).css('display','none');
    });




    $(this).click(function() {
        setTimeout(function() {
            $(ctrl).find('td').each(function() {
                if ( $(this).find('input').first().is(':checked') )
                    $(this).attr('class', 'active');
                else
                    $(this).attr('class', '');
            });
        },100);
    });




    $(this).attr('class', classButton);
    $(this).find('label').each(function() { $(this).css('cursor', 'pointer'); });
    $(this).find('span').each(function() { $(this).css('cursor', 'pointer'); });
    $(this).find('td').each(function(){
        $(this).click(function(e) {
            e.preventDefault();
            $(this).find('input').first().click();
        });
    });




    return this;
}




$.fn.rdfvtrbuttons = function( options ) {
    var ctrl = this;
    var className = $(this).attr("class");
    var classButton = (typeof className === 'undefined')? 'rdf-vtbutton' : className+'-rdf-vtbutton';




    $(this).find('td').each(function() {
        if ( $(this).find('input').first().is(':checked') ) {
            $(this).toggleClass('active');
        }
    });




    /* Hide extra td created by WF 8.0.09 */
    $(this).find('td:nth-child(2)').css('display','none');




    $(this).attr('class', classButton);
    $(this).find('label').each(function() { $(this).css('cursor', 'pointer'); });
    $(this).find('span').each(function() { $(this).css('cursor', 'pointer'); });
    $(this).find('td').each(function(){
        $(this).click(function(e) {
            //e.preventDefault();
            var currentId = $(this).find('input').first().attr('id');
            $(ctrl).find('input').each(function(){
                if ( $(this).attr('id') != currentId )
                    this.checked = false;
                else
                    this.checked = true;
            });
            setTimeout(function(){ resetButtonSet(ctrl); },100);
        });
    });




    return this;
}




function resetButtonSet(ctrl) {
    $(ctrl).find('td').each(function() {
        if ( $(this).find('input').first().is(':checked') )
            $(this).attr('class', 'active');
        else
            $(this).attr('class', '');
    });
}




$.fn.rdflistbox = function( options ) {
    var settings = $.extend({
        visibility: "visible",
        search: false,
        multiple: false
        }, options );


    var className = $(this).attr("class");
    var classDropDown = (typeof className === 'undefined')? 'rdf-dropdown' : className+'-rdf-dropdown';
    var classText = (typeof className === 'undefined')? 'rdf-text' : className+'-rdf-text';
    var classTextDisabled = (typeof className === 'undefined')? 'rdf-text-disabled' : className+'-rdf-text-disabled';
    var classTextActive = (typeof className === 'undefined')? 'rdf-text-active' : className+'-rdf-text-active';
    var top = parseInt($(this).css("top"));
    var left = $(this)[0].style.left;
    var width = (document.getElementById( $(this).attr('id') ).style.width.indexOf("%")>=0)? document.getElementById( $(this).attr('id') ).style.width : parseInt($(this).css("width")) + 'px';
    var minWidth = parseInt($(this).css("min-width"));
    var maxWidth = parseInt($(this).css("max-width"));
    var height = parseInt($(this).css("height"));
    var ctrl = this;




    /* Set the class and reset CSS Styles */
    $(this).attr("class", classDropDown);
    $(this).css( {'left': left, 'top': top+height+'px', 'width': '', 'min-width': '', 'max-width': '', 'height': '', 'overflow': ''} );
        // shravan's code
    $(this).find('table').removeAttr('class');








    /* Set the class and reset CSS Styles */
    $(this).parent().append('<div id="' + $(this).attr('id') + '-display"></div>');
    $('#'+$(this).attr('id')+'-display').attr("class", classText);




    $('#'+$(this).attr('id')+'-display').css( {'position': 'absolute', 'top': top + 'px', 'left': left, 'width': width, 'min-width': minWidth + 'px', 'max-width': maxWidth + 'px', 'height': height + 'px'} );
    $('#'+$(this).attr('id')+'-display').click(function() {
        if ($( this ).attr("class") != classTextDisabled) {
            $( this ).attr("class", classTextActive);
            //var leftOffset =  ( ($(ctrl).offset().left+$(ctrl).width()) > ($(window).width()-20) )? $(ctrl).offset().left+width-$(ctrl).width() : $(ctrl).offset().left;
            $( ctrl ).css( {'position': 'absolute', 'top': $( this ).offset().top+height+4+'px', 'left': $( this ).offset().left+'px', 'display': 'block'} ).appendTo( 'body' );
        }
    });




    /* Add OnBlur */
    $(document).mouseup(function (e) {
        //if ($( ctrl ).is(":visible") && $(e.target).parents( '.'+classDropDown ).length == 0 && e.target.id !== $(ctrl).attr('id') && e.target.tagName != 'HTML') {
        if ($( ctrl ).is(":visible") && $(e.target).parents( '.'+classDropDown ).length == 0 && e.target.id !== $(ctrl).attr('id') && e.target.tagName != 'HTML'){
      //      $( ctrl ).hide();
            $('#'+$(ctrl).attr('id')+'-display').attr("class", classText);
            // shravan's code
            if(settings.hideCallback != null) { settings.hideCallback($(ctrl)); }
        }
    });
    $(document).on({ 'touchstart' : function (e) {
        if ($( ctrl ).is(":visible") && $(e.target).parents( '.'+classDropDown ).length == 0 && e.target.id !== $(ctrl).attr('id')) {
            $( ctrl ).hide();
            $('#'+$(ctrl).attr('id')+'-display').attr("class", classText);
                    // shravan's code
            if(settings.hideCallback != null) { settings.hideCallback($(ctrl)); }
        }
    }});


    $(this).mouseleave(function(){
        var thisUI = $(this);
        $('html').click(function(){
                thisUI.hide();
            $('html').unbind('click');
         });
     });


    /* Add OnChange */
  /*  $(this).change(function() {
        if (typeof $(this).find('table').first().attr('rdf')  === 'undefined' )
            resetDropdown( ctrl, settings, className );
    });*/
    // shravan's changes
    $(this).change(function()
    {
       if (typeof $(ctrl).find('table').first().attr('multi')  === 'undefined' )
       {
          resetDropdown( ctrl, settings, className );
       }
       else
       {
          var text = "";
          $(ctrl).find('input[type=checkbox]').each(function()
          {
             if (this.checked)
             {
                $(this).parent().parent().attr("class", "active");
                text += (text.trim() == '')? $(this).parent().text(): ', ' + $(this).parent().text();
             }
             else
             {
                $(this).parent().parent().removeAttr("class");
             }
          });
          $('#'+$(ctrl).attr('id')+'-display').html(text);
          $('#'+$(ctrl).attr('id')+'-display').attr('title', text);
       }
    });




    /* Reset Drop Menu */
    resetDropdown( ctrl, settings, className );




    return this;
};




function updateSearchResult(ctrl) {
    var txt = ctrl.value.toLowerCase();
    var tds = $(ctrl).parent().parent().find('td');




    tds.each(function() {
        if ($(this).text().toLowerCase().indexOf( txt ) < 0)
            $(this).parent().css("display", "none");
    else
            $(this).parent().css("display", "table-row");
    });
}




function resetDropdown(ctrl, settings, className) {
    var classText = (typeof className === 'undefined')? 'rdf-text' : className+'-rdf-text';
    var classInputHidden = (typeof className === 'undefined')? 'rdf-input-hidden' : className+'-rdf-input-hidden';
    var checkedBoxes = 0;
    /* Mark the table */
    $(ctrl).find('table').first().attr('rdf', true);




    /* Set Default Selections */
    var text = "";
    $(ctrl).find('input[type=checkbox]').each(function() {
        if (this.checked)
        {
            checkedBoxes = checkedBoxes +1;
            $(this).parent().parent().attr("class", "active");
            text += (text.trim() == '')? $(this).parent().text(): ', ' + $(this).parent().text();
        }
    });
    // Shravan Panuganti: 03/18/2016 - If none of the checkboxes are checked, checke the first one
    if(checkedBoxes == 0)
    {
       $(ctrl).find('input[type=checkbox]').first().click();
    }
    $('#'+$(ctrl).attr('id')+'-display').html(text);
    $('#'+$(ctrl).attr('id')+'-display').attr('title', text);




    /* Add Search */
    if ( settings.search ) {
        $(ctrl).prepend('<div style="border-bottom: 1px solid #999; width: 100%; height: 30px;"><input class="rdf-searchbox" type="text" style="width:85%" value="" onkeyup="updateSearchResult(this)"></div>');
    }




    /* Add OnClick function to set active selections and display text */
    $(ctrl).find('label').each(function() { $(this).css('cursor', 'pointer'); });
    $(ctrl).find('span').each(function() { $(this).css('cursor', 'pointer'); });
    $(ctrl).find('input[type=checkbox]').each(function() {
        /* Settings */
        $(this).css( {'margin': '', 'padding-left': ''} );
        if ( settings.visibility != 'visible' )
            $(this).attr('class', classInputHidden);




        /* Click */
        $(this).click(function() {
            if (!settings.multiple) {
                if (!this.checked) { this.checked = true; }
            }
            setTimeout(function() {
                var text = '';
                $( ctrl ).find('input[type=checkbox]').each(function() {
                    if (this.checked) {
                        $(this).parent().parent().attr("class", "active");
                        text += (text.trim() == '')? $(this).parent().text(): ', ' + $(this).parent().text();
                    }
                    else
                        $(this).parent().parent().removeAttr("class");
                });
                $('#'+$(ctrl).attr('id')+'-display').html(text);
                $('#'+$(ctrl).attr('id')+'-display').attr('title', text);
                if (!settings.multiple) {
                    $( ctrl ).hide();
                    $('#'+$(ctrl).attr('id')+'-display').attr("class", classText);
                }
            },100);
        });
    });
    $(ctrl).find('td').each(function(){
        $(this).click(function(e) {
            e.preventDefault();
            $(this).find('input[type=checkbox]').first().click();
        });
    });
}




/*
 * RDF Plug-in - rdfvtab
 */
$.fn.rdfvtab = function( options ) {
    var ctrl = this;
    var originalText = $(this).html();
    var panel = $(this).parent().parent();




    $( this ).css("position", "absolute");




    var settings = $.extend({
        state: "open"
        }, options );




    /* Set the Class Name */
    if (settings.state == "open") {
        $( this ).html("Hide " + originalText);
        $( this ).attr("class", "rdf-toggle-tab-up");
    }
    else {
        $( this ).html("Show " + originalText);
        $( this ).attr("class", "rdf-toggle-tab-down");
    }




    /* Add Click */
    $( this ).click(function() {
        if ($( this ).attr("class") == "rdf-toggle-tab-up") {
            $( this ).html("Show " + originalText);
            $( this ).attr("class", "rdf-toggle-tab-down");
            var topOffset =  panel.height() - 20;
            panel.children().each(function() {
                $(this).css("top", -1*topOffset+'px');
            });
            panel.css('height', '20px');
        }
        else {
            $( this ).html("Hide " + originalText);
            $( this ).attr("class", "rdf-toggle-tab-up");
            panel.children().each(function() {
                this.style.top = "auto";
            });
            panel.css('height', 'auto');
        }
    });




    return this;
}


// I created this function with a small variation from rdflistbox
$.fn.OpenListBox = function( options ) {
    var settings = $.extend({
        visibility: "visible",
        search: false,
        multiple: false
        }, options );


    var className = $(this).attr("class");
    var classDropDown = (typeof className === 'undefined')? 'rdf-dropdown' : className+'-rdf-dropdown';
    var classText = (typeof className === 'undefined')? 'rdf-text' : className+'-rdf-text';
    var classTextDisabled = (typeof className === 'undefined')? 'rdf-text-disabled' : className+'-rdf-text-disabled';
    var classTextActive = (typeof className === 'undefined')? 'rdf-text-active' : className+'-rdf-text-active';
    var top = parseInt($(this).css("top"));
    var left = $(this)[0].style.left;
    var width = (document.getElementById( $(this).attr('id') ).style.width.indexOf("%")>=0)? document.getElementById( $(this).attr('id') ).style.width : parseInt($(this).css("width")) + 'px';
    var minWidth = parseInt($(this).css("min-width"));
    var maxWidth = parseInt($(this).css("max-width"));
    var height = parseInt($(this).css("height"));
    var ctrl = this;


     /* Set the class and reset CSS Styles */
    $(this).attr("class", classDropDown);
    $(this).css( {'left': left, 'top': top+height+'px', 'width': '', 'min-width': '', 'max-width': '', 'height': '', 'overflow': ''} );
    $(this).find('table').removeAttr('class');


     /* Set the class and reset CSS Styles */
    $(this).parent().append('<div id="' + $(this).attr('id') + '-display"></div>');
    $('#'+$(this).attr('id')+'-display').attr("class", classText);


    $('#'+$(this).attr('id')+'-display').css( {'position': 'absolute', 'top': top + 'px', 'left': left, 'width': width, 'min-width': minWidth + 'px', 'max-width': maxWidth + 'px', 'height': height + 'px'} );
    $('#'+$(this).attr('id')+'-display').click(function() {
        if ($( this ).attr("class") != classTextDisabled)
        {
            $( this ).attr("class", classTextActive);
            //var leftOffset =  ( ($(ctrl).offset().left+$(ctrl).width()) > ($(window).width()-20) )? $(ctrl).offset().left+width-$(ctrl).width() : $(ctrl).offset().left;
            $( ctrl ).css( {'position': 'absolute', 'top': $( this ).offset().top+height+4+'px', 'left': $( this ).offset().left+'px', 'display': 'block'} ).appendTo( 'body' );
        }
    });


    /* Add OnBlur */
    $(document).mouseup(function (e)
    {
        if ($( ctrl ).is(":visible") && $(e.target).parents( '.'+classDropDown ).length == 0 && e.target.id !== $(ctrl).attr('id') && e.target.tagName != 'HTML') {
          //  $( ctrl ).hide();
            $('#'+$(ctrl).attr('id')+'-display').attr("class", classText);
            // shravan's code
            if(settings.hideCallback != null) { settings.hideCallback($(ctrl)); }
        }
    });
    $(document).on({ 'touchstart' : function (e) {
        if ($( ctrl ).is(":visible") && $(e.target).parents( '.'+classDropDown ).length == 0 && e.target.id !== $(ctrl).attr('id')) {
            $( ctrl ).hide();
            $('#'+$(ctrl).attr('id')+'-display').attr("class", classText);
                    // shravan's code
            if(settings.hideCallback != null) { settings.hideCallback($(ctrl)); }
        }
    }});


    $(this).mouseleave(function(){
        var thisUI = $(this);
        $('html').click(function(){
                thisUI.hide();
            $('html').unbind('click');
         });
     });
    $(this).change(function()
    {
       if (typeof $(ctrl).find('table').first().attr('multi')  === 'undefined' )
       {
          resetDropdown( ctrl, settings, className );
       }
       else
       {
          var text = "";
          $(ctrl).find('input[type=checkbox]').each(function()
          {
             if (this.checked)
             {
                $(this).parent().parent().attr("class", "active");
                text += (text.trim() == '')? $(this).parent().text(): ', ' + $(this).parent().text();
             }
             else
             {
                $(this).parent().parent().removeAttr("class");
             }
          });
          $('#'+$(ctrl).attr('id')+'-display').html(text);
          $('#'+$(ctrl).attr('id')+'-display').attr('title', text);
       }
    });


    /* Reset Drop Menu */
    resetOpenList( ctrl, settings, className );


    return this;


 }


function resetOpenList(ctrl, settings, className)
{
 var classText = (typeof className === 'undefined')? 'rdf-text' : className+'-rdf-text';
    var classInputHidden = (typeof className === 'undefined')? 'rdf-input-hidden' : className+'-rdf-input-hidden';
    var checkedBoxes = 0;
    /* Mark the table */
    $(ctrl).find('table').first().attr('rdf', true);


    /* Set Default Selections */
    var text = "";
    $(ctrl).find('input[type=checkbox]').each(function()
 {
        if (this.checked)
        {
            checkedBoxes = checkedBoxes +1;
            $(this).parent().parent().attr("class", "active");
            text += (text.trim() == '')? $(this).parent().text(): ', ' + $(this).parent().text();
        }
    });


    if(checkedBoxes == 0)
    {
       $(ctrl).find('input[type=checkbox]').first().click();
    }


    $('#'+$(ctrl).attr('id')+'-display').html(text);
    $('#'+$(ctrl).attr('id')+'-display').attr('title', text);


    /* Add Search */
    if ( settings.search )
 {
        $(ctrl).prepend('<div style="border-bottom: 1px solid #999; width: 100%; height: 30px;"><input class="rdf-searchbox" type="text" style="width:85%" value="" onkeyup="updateSearchResult(this)"></div>');
    }


    /* Add OnClick function to set active selections and display text */
    $(ctrl).find('label').each(function() { $(this).css('cursor', 'pointer'); });
    $(ctrl).find('span').each(function() { $(this).css('cursor', 'pointer'); });


 $(ctrl).find('input[type=checkbox]').each(function()
 {
  /* Settings */
        $(this).css( {'margin': '', 'padding-left': ''} );


  if ( settings.visibility != 'visible' )
            $(this).attr('class', classInputHidden);


        /* Click */
        $(this).click(function()
  {
            if (!settings.multiple)
   {
                if (!this.checked) { this.checked = true; }
   }


   setTimeout(function()
   {
                var text = '';
                $( ctrl ).find('input[type=checkbox]').each(function()
    {
     if (this.checked)
     {
                        $(this).parent().parent().attr("class", "active");
                        text += (text.trim() == '')? $(this).parent().text(): ', ' + $(this).parent().text();
                    }
                    else
                        $(this).parent().parent().removeAttr("class");
                });


    $('#'+$(ctrl).attr('id')+'-display').html(text);
                $('#'+$(ctrl).attr('id')+'-display').attr('title', text);
                if (!settings.multiple)
    {
                    $( ctrl ).hide();
                    $('#'+$(ctrl).attr('id')+'-display').attr("class", classText);
                }
            },100);
        });
    });


 $(ctrl).find('td').each(function()
 {
        $(this).click(function(e)
  {
            e.preventDefault();
            $(this).find('input[type=checkbox]').first().click();
        });
    });
}






