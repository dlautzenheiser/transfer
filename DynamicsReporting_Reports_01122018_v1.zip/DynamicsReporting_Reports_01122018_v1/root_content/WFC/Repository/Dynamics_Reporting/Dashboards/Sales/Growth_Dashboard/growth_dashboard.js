// =====================================================================================================================
//                                                 Custom Reports - JavaScript
// ---------------------------------------------------------------------------------------------------------------------

//        Date: 12/27/2017                Created By   : Shravan Panuganti


// ======================================================================================================================
//                                                Dashboard Components
// ----------------------------------------------------------------------------------------------------------------------

var Components =
[
    'won_to_goal_current_fiscal_year',
    'wins_by_lob_current_fiscal_year',
    'international_wins_credit_approved_fiscal_year',
    'won_to_goal_for_current_fiscal_quarter',
    'wins_by_industry_current_fiscal_year',
    'won_lost_withdrawn_current_fiscal'
];

var ThisComponentNumber = 1;

var ThisPath = '/ibi_apps/WFServlet.ibfs?IBFS1_action=RUNFEX&IBFS_path=/WFC/Repository/Dynamics_Reporting/Sales/InfoAssist/Dashboards/Growth_Dashboard/';

// ======================================================================================================================
//                                               Other Constants and Variables
// ----------------------------------------------------------------------------------------------------------------------

var userAgent = navigator.userAgent.toString().toLowerCase();
var BrowserName=  '';

var nVer = navigator.appVersion;
var nAgt = navigator.userAgent;
var browserName  = 'Microsoft Internet Explorer';
var nameOffset,verOffset,ix;

// In Opera, the true version is after "Opera" or after "Version"
if ((verOffset=nAgt.indexOf("Opera"))!=-1)
    browserName = "Opera";

// In MSIE, the true version is after "MSIE" in userAgent
else if ((verOffset=nAgt.indexOf("MSIE"))!=-1)
   browserName = "Microsoft Internet Explorer";
// In Chrome, the true version is after "Chrome"
else if ((verOffset=nAgt.indexOf("Chrome"))!=-1)
   browserName = "Chrome";
// In Safari, the true version is after "Safari" or after "Version"
else if ((verOffset=nAgt.indexOf("Safari"))!=-1)
   browserName = "Safari";
// In Firefox, the true version is after "Firefox"
else if ((verOffset=nAgt.indexOf("Firefox"))!=-1)
    browserName = "Firefox";
// In most other browsers, "name/version" is at the end of userAgent
else if ( (nameOffset=nAgt.lastIndexOf(' ')+1) < (verOffset=nAgt.lastIndexOf('/')) )
    browserName = nAgt.substring(nameOffset,verOffset);

    var ThisPanelOriginalHeight = 300;
    var ThisPanelOriginalWidth = 400;

    var Expanded = 0;

    var Thispanel = 'MainPanel_ChildPanel1';
    var ThisFrame = 'chart1';

// ========================================================================================================================

function OpenObject(ThisObject)
{
    var ThisObjectId = ThisObject;

    ThisPanel = $('#' + ThisObjectId).parent().parent().attr('id');
    ThisFrame = $('#' + ThisPanel).find('iframe').attr('id');

    ThisComponentNumber = ThisObjectId.toString().substring(6, 7);

    $('#ObjectNameEdit').val(Components[ThisComponentNumber - 1]);

    $('#ThisFrameIdEdit').val(ThisFrame);

    $('#CallInfoAssistButton').click();
}

function PopupReport(Title, Path, CurrentFrame)
{
  //  alert(CurrentFrame);
    $("html, body").animate({ scrollTop: 0 }, "slow");
    var Title = Title.replace(/@_#/g, '\'');
    $('body').append('<div id="AlertDiv" style="position:absolute;left:0px;top:0px;width:100%;height:100%;background-color:rgba(0,0,0,.4);z-index:999"></div>');

    if(browserName == 'Safari')
        $('#AlertDiv').append('<div id="AlertBody" style="text-align: center;width:100%;height:1000px;margin-left: auto;margin-right: auto;top:50px;" class="alertbox"></span><br><br><br></div>');
    else
            $('#AlertDiv').append('<div id="AlertBody" style="text-align: center;width:100%;height:calc(100% - 50px);margin-left: auto;margin-right: auto;top:50px;" class="alertbox"></span><br><br><br></div>');
    $('#AlertDiv').append('<span class="popup_report_title_bar" style="position:absolute;top:0px;left:0px;width:100%;height:50px;line-height:45px;"></span>');
    $('.popup_report_title_bar').append('<input type="button" value="" class="popup_report_close" style="position:absolute;top:10px;right:10px;width:25px;height:25px" onclick="HidePopupReport(' + CurrentFrame + ');">');
    $('.popup_report_title_bar').append('<span class="popup_report_title" style="position:absolute;top:10px;left:10%;width:80%;height:30px;">' + Title + '</span>');
    $("#AlertBody").append('<iframe id="Popup_Report_frame" class="report_frame" style="position:absolute;top:0px;left:0px;width:100%;height:100%;"></iframe>');
    $("#Popup_Report_frame").attr('src', Path );

    $('#LoadingWaitPanel').css({'visibility': 'hidden'});

//    $('.IBI_PageBg').css({'overflow': 'hidden'});
}

function HidePopupReport(CurrentFrame)
{
    $('#AlertDiv').fadeOut("slow", function() { $('#AlertDiv').remove();});
 //   $('.IBI_PageBg').css({'overflow': 'scroll'});
    ReArrangeComponents();
 }

$( ".edit_button" ).each(function(index) {
    $(this).on("click", function(){
        var ThisObjectId = $(this).attr('id');

 //   PleaseWait();
        OpenObject(ThisObjectId);
    });
});

$( ".expand_button" ).each(function(index)
{
        $(this).on("click", function()
        {
            var ThisObjectId = $(this).attr('id');

            if(Expanded == 0)
            {
                $( this ).addClass("contract_button");

                $( ".edit_button" ).css({"visibility": "hidden"});

                ShowInFullScreen(ThisObjectId);

                Expanded = 1;
            }
            else
            {

                //$( ".edit_button" ).css({"visibility": "visible"});
                
                VerifyEditAccess();

                $( this ).removeClass("contract_button");

                ShowInChildPanel(ThisObjectId);

                Expanded = 0;
            }
        });
});

function ShowInFullScreen(ThisObject)
{
    var ThisObjectId = ThisObject;

    ThisPanel = $('#' + ThisObjectId).parent().parent().attr('id');
    ThisFrame = $('#' + ThisPanel).find('iframe').attr('id');

 //   ThisPanelOriginalHeight = $('#' + ThisPanel).height();
//    ThisPanelOriginalWidth = $('#' + ThisPanel).width();

    $('#' + ThisPanel).animate({ "width": "100%", "height": "100%" });

    $('#' + ThisFrame).css({"width": "100%", "height": "calc(93% - 4px)"})

    $(".main_panel_child_panel:not(#" + ThisPanel+ ")").fadeOut();
}

function ShowInChildPanel(ThisObject)
{
    var ThisObjectId = ThisObject;

    ThisPanel = $('#' + ThisObjectId).parent().parent().attr('id');
    ThisFrame = $('#' + ThisPanel).find('iframe').attr('id');

//    $('#' + ThisPanel).animate({ "width": ThisPanelOriginalWidth + "px", "height": ThisPanelOriginalHeight + "px" });
    $('.main_panel_child_panel ').animate({'height': '300px'});

    ReArrangeComponents();

    $('#' + ThisFrame).css({"width": "100%", "height": "100%"})

    $(".main_panel_child_panel").fadeIn();
}

function PleaseWait()
{
    $('#LoadingWaitPanel').css({'visibility': 'visible'});
}

//Begin function PipeLineDashboardLink_onclick
function PipeLineDashboardLink_onclick(event) {
    var eventObject = event ? event : window.event;
    var ctrl = eventObject.target ? eventObject.target : eventObject.srcElement;
    // TODO: Add your event handler code here
    
    
    window.open("bip/portal/NSOPipelineDashboard", "_self");
    }
    //End function PipeLineDashboardLink_onclick
